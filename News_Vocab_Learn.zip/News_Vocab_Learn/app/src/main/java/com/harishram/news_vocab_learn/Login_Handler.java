package com.harishram.news_vocab_learn;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Login_Handler extends AsyncTask<String, Void, Void> {
    String username,password,url;
    URL login_url;
    HttpURLConnection login_connection;
    String result="";
    String result_array[];
    Context context;
    public Login_Handler(Context context){
        this.context = context;
    }
    @Override
    protected Void doInBackground(String... strings) {
        username = strings[0];
        password = strings[1];
        url = "http://192.168.43.100/news_vocab_learn_server/login_check.php?username="+username+"&password="+password;
        try {
            login_url = new URL(url);
            login_connection = (HttpURLConnection) login_url.openConnection();
            login_connection.setDoOutput(true);
            login_connection.setRequestMethod("GET");
            BufferedReader login_br = new BufferedReader(new InputStreamReader(login_connection.getInputStream()));
            result = login_br.readLine();
            System.out.println(result);
            result_array = result.split(",");
            if(result_array.length == 2){
                Intent menu_intent = new Intent(context,User_Menu.class);
                Bundle b = new Bundle();
                b.putString("username",username);
                b.putString("password",password);
                b.putString("address",result_array[1]);
                menu_intent.putExtra("user_info",b);
                context.startActivity(menu_intent);
            }
            else{
                Toast error_info = Toast.makeText(context,"Invalid Username or password.Try again",Toast.LENGTH_SHORT);
                error_info.show();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}

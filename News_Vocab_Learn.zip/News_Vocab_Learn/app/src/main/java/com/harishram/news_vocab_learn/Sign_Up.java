package com.harishram.news_vocab_learn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Sign_Up extends AppCompatActivity {
    EditText name, username, password, re_password, address;
    TextView submit;
    String name_text, username_text, password_text, address_text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_sign_up);
        name = (EditText) findViewById(R.id.editText3);
        username = (EditText) findViewById(R.id.editText5);
        password = (EditText) findViewById(R.id.editText11);
        re_password = (EditText) findViewById(R.id.editText7);
        address = (EditText) findViewById(R.id.editText10);
        submit = (TextView) findViewById(R.id.textView12);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getText().toString().equals(re_password.getText().toString())){
                    name_text = name.getText().toString();
                    username_text = username.getText().toString();
                    password_text = password.getText().toString();
                    address_text = address.getText().toString();
                    SignUp_Handler suh = new SignUp_Handler();
                    suh.execute(name_text,username_text,password_text,address_text);
                    Intent login_intent = new Intent(getApplicationContext(),Login.class);
                    startActivity(login_intent);
                }
                else{
                    Toast error_msg = Toast.makeText(getApplicationContext(),"Passwords do not match. Try again", Toast.LENGTH_SHORT);
                    error_msg.show();
                }
            }
        });
    }

    @Override
    public void onBackPressed(){
        Intent login_intent = new Intent(this, Login.class);   // Intent created to go to login screen when back button in keypad is pressed
        startActivity(login_intent);    // Goes to login screen
    }
}

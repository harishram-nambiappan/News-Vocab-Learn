\<?php
   $username = $_GET['username'];
   $password = $_GET['password'];
   $result = "";
   $login_conn = mysqli_connect("localhost","admin","Pyro*0085","news_vocab_learn");
   if($login_conn){
     $query = "SELECT * FROM user_info WHERE username='hari' and password='$password'";
     $login_query = mysqli_query($login_conn,$query);
     if(mysqli_num_rows($login_query)>0){
     while($row = mysqli_fetch_array($login_query)){
       echo "Success,".$row['address'];
     }
     }
     else{
       echo "Error";
    }
    
  }
?>

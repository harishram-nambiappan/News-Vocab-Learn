package com.harishram.news_vocab_learn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {
     EditText username, password;
     String username_info, password_info;
     TextView login, sign_up;
     String response;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.editText);
        password = (EditText) findViewById(R.id.editText2);
        login = (TextView) findViewById(R.id.textView8);
        sign_up = (TextView) findViewById(R.id.textView9);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username_info = username.getText().toString();
                password_info = password.getText().toString();
                Login_Handler login_check = new Login_Handler(getApplicationContext());
                login_check.execute(username_info,password_info);
            }
        });
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sign_up_intent = new Intent(getApplicationContext(), Sign_Up.class);
                startActivity(sign_up_intent);
            }
        });


    }
}

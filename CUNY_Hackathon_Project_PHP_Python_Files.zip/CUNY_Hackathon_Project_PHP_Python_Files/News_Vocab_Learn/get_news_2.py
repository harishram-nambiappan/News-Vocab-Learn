import requests
import sys
import random

url = "http://newsapi.org/v2/top-headlines?country=us&apiKey=2eaeefe718044db3b75aceb0f30dae45"
response = requests.get(url)
result = response.json()
i = random.randint(0,len(result["articles"])-1)
url = result["articles"][i]["url"]
content = result["articles"][i]["description"]
wordcount = {}
wordlist = []
for word in content.split():
    if word not in wordcount:
        wordcount[word] = 1
        wordlist.append(word)
    else:
        wordcount[word] += 1
i = random.randint(0,len(wordlist)-1)
json_result = {'url': url, 'word': str(wordlist[i]), 'content':content}
print(json_result)
sys.exit(json_result)

package com.harishram.news_vocab_learn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class First_Time_Set_Up extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_set_up);
    }
}

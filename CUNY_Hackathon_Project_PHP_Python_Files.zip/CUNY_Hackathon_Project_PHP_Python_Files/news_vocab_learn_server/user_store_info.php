<?php
   $name = $_POST['name'];
   $username = $_POST['username'];
   $password = $_POST['password'];
   $address = $_POST['address'];
   $store_info_conn = mysqli_connect("localhost","admin","Pyro*0085","news_vocab_learn");
   if($store_info_conn){
     echo "Connected successfully";
  }
  $insert_query = "INSERT INTO user_info (name,username,password,address) VALUES('$name','$username','$password','$address')";
  echo $insert_query;
  $store_info = mysqli_query($store_info_conn,$insert_query);
  if($store_info){
     echo "Inserted successfully";
     $result['name']=$name;
     $result['password']=$password;
     $result['username']=$username;
     $result['address']=$address;
     echo json_encode($result);
  }
  mysqli_close($store_info_conn);
?>

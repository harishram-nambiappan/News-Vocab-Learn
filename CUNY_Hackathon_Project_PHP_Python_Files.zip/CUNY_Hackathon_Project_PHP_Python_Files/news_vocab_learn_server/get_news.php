<?php
   $py_exec = escapeshellcmd('python3 /home/pi/News_Vocab_Learn/get_news.py');
   $py_result =  shell_exec($py_exec);
   echo $py_result;
?>

package com.harishram.news_vocab_learn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class User_Menu extends AppCompatActivity {
    TextView vocabulary,wordfind,exit;
    Bundle user_info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_user_menu);
        user_info = getIntent().getBundleExtra("user_info");
        vocabulary = (TextView) findViewById(R.id.textView3);
        wordfind = (TextView) findViewById(R.id.textView4);
        exit = (TextView) findViewById(R.id.textView6);
        vocabulary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent vocab_intent = new Intent(getApplicationContext(), Vocabulary_With_Newspaper.class);
                vocab_intent.putExtra("user_info",user_info);
                startActivity(vocab_intent);
            }
        });
        wordfind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent wordfind_intent = new Intent(getApplicationContext(), WordFind_With_Newspaper.class);
                wordfind_intent.putExtra("user_info",user_info);
                startActivity(wordfind_intent);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent exit_intent = new Intent(getApplicationContext(), Login.class);
                startActivity(exit_intent);
            }
        });
    }
}

package com.harishram.news_vocab_learn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;

public class WordFind_With_Newspaper extends AppCompatActivity {
    TextView play,Back,Submit;
    EditText answer_text;
    Bundle user_info;
    WebView news_clip;
    Thread news_retrieval;
    String address,url,results;
    JSONObject results_json;
    URL news_url;
    HttpURLConnection news_conn;
    String load_url= "";
    TextToSpeech tts;
    String word,answer,content;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_word_find_with_newspaper);
        user_info = getIntent().getBundleExtra("user_info");
        play = (TextView) findViewById(R.id.textView18);
        Back = (TextView) findViewById(R.id.textView19);
        Submit = (TextView) findViewById(R.id.textView20);
        news_clip = (WebView) findViewById(R.id.webView2);
        answer_text = (EditText) findViewById(R.id.editText8);
        address = user_info.getString("address");
        url = "http://"+address+"/news_vocab_learn_server/get_news_2.php";
        try {
            news_url = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        news_retrieval = new Thread(new Runnable(){

            @Override
            public void run() {
                try {
                    news_conn = (HttpURLConnection) news_url.openConnection();
                    news_conn.setDoOutput(true);
                    news_conn.setRequestMethod("GET");
                    Thread.sleep(3000);
                    BufferedReader br = new BufferedReader(new InputStreamReader(news_conn.getInputStream()));
                    results = br.readLine();
                    System.out.println("Inside Thread:"+results);
                    results_json = new JSONObject(results);
                    load_url = results_json.getString("url");
                    word = results_json.getString("word");
                    content = results_json.getString("content");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        news_retrieval.start();
        try {
            news_retrieval.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(load_url);
        news_clip.loadUrl(load_url);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        tts.setLanguage(Locale.US);
                        tts.speak(word, TextToSpeech.QUEUE_ADD,null);
                    }
                });
            }
        });
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(getApplicationContext(), User_Menu.class);
                back_intent.putExtra("user_info",user_info);
                startActivity(back_intent);
            }
        });
        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                answer = answer_text.getText().toString();
                if(answer.equals(content)){
                    Toast correct = Toast.makeText(getApplicationContext(), "Correct Answer", Toast.LENGTH_SHORT);
                    correct.show();
                    Intent submit_intent = new Intent(getApplicationContext(), User_Menu.class);
                    submit_intent.putExtra("user_info", user_info);
                    startActivity(submit_intent);
                }
                else{
                    Toast wrong = Toast.makeText(getApplicationContext(),"Wrong Answer. Try again", Toast.LENGTH_SHORT);
                    wrong.show();
                }

            }
        });
    }
}

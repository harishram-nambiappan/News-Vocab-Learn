package com.harishram.news_vocab_learn;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class SignUp_Handler extends AsyncTask<String,Void,Void> {
    String name,username,password,address;
    String url;
    URL url_link;
    HttpURLConnection signup_connection;
    String signup_param;
    @Override
    protected Void doInBackground(String... strings) {
        name = strings[0];
        username = strings[1];
        password = strings[2];
        address = strings[3];
        url = "http://"+address+"/news_vocab_learn_server/user_store_info.php";
        try {
            signup_param = "name="+name+"&username="+username+"&password="+password+"&address="+address;
            url_link = new URL(url);
            signup_connection = (HttpURLConnection) url_link.openConnection();
            signup_connection.setDoOutput(true);
            signup_connection.setRequestMethod("POST");
            OutputStream signup_os = signup_connection.getOutputStream();
            OutputStreamWriter signup_osw = new OutputStreamWriter(signup_os,"UTF-8");
            BufferedWriter signup_bw = new BufferedWriter(signup_osw);
            signup_bw.write(signup_param);
            signup_bw.flush();
            System.out.println(signup_connection.getResponseCode());
            BufferedReader signup_br = new BufferedReader(new InputStreamReader(signup_connection.getInputStream()));
            System.out.println(signup_br.readLine());

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
